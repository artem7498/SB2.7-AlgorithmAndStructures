import UIKit
import Foundation

var str = "Hello, playground"

//2. Реализуйте класс linked list, работающий только со строками. Сделайте в нём функцию поиска строки.

class LinkedList<String: Equatable> {
    var key: String?
    var next: LinkedList<String>?
    var previous: LinkedList<String>?
    
    var array: [String] = []
    
    init(value: String?) {
        key = value
    }
    
    convenience init(values: [String]) {
        self.init(value: values.first)
        array = values
        var current = self
        for i in 1..<values.count{
            let next = LinkedList(value: values[i])
            current.next = next
            current = next as! Self
        }
        print(array)
    }
    
    func search(_ str: String) -> String{
        for i in array{
            if i == str {
                return i
//                print(i)
            }
        }
        return "No matches found" as! String
    }

    
}

let myList = LinkedList(values: ["Harry", "Ann", "Lizy", "Peter", "Ana", "Londa"])
myList.key

myList.search("Ana")

let klist = LinkedList(values: ["Londa"])
klist.search("Londa")





//3. Реализуйте класс для бинарного дерева поиска, работающий только со строками. Сделайте в нём функцию поиска.

class TreeNode<String: Comparable>{
    var value: String
    
    var parent: TreeNode<String>?
    var left: TreeNode<String>?
    var right: TreeNode<String>?
    
    var array: [String] = []
    
    init(value: String) {
        self.value = value
    }
    
    convenience init(values: [String]){
        precondition(values.count > 0)
        self.init(value: values.first!)
        array = values
        for v in values.dropFirst() {
            insert(value: v)
        }
    }
    
    public func insert(value: String) {
        if value < self.value {
          if let left = left {
            left.insert(value: value)
          } else {
            left = TreeNode(value: value)
            left?.parent = self
          }
        } else {
          if let right = right {
            right.insert(value: value)
          } else {
            right = TreeNode(value: value)
            right?.parent = self
          }
        }
      }
    
    func arraySearch(_ str: String) -> String{
        for i in array{
            if i == str {
                return i
            }
        }
        return "No matches found" as! String
    }
    
    func search(_ value: String) -> TreeNode? {
       if value < self.value {
        return left?.search(value)
       } else if value > self.value {
        return right?.search(value)
       } else {
         return self  // found it!
       }
     }
    
    func searchLoop(_ value: String) -> TreeNode? {
      var node: TreeNode? = self
      while let n = node {
        if value < n.value {
          node = n.left
        } else if value > n.value {
          node = n.right
        } else {
          return node
        }
      }
      return nil
    }
    
}

let myTree = TreeNode(values: ["Harry", "Ann", "Lizy", "Peter", "Ana", "Londa"])

myTree.arraySearch("Peter")
myTree.searchLoop("Ana")
myTree.search("Lizy")
myTree.insert(value: "Vella")

myTree.search("Vella")

myTree.arraySearch("Vella")


let top = TreeNode(value: "Hurry")
let left = TreeNode(value: "Potter")
let right = TreeNode(value: "Griffindor")
top.left = left
top.right = right

top.search("Potter")



//4. Реализуйте класс для графа со станциями метро, где рёбра хранят в себе длительность переезда между двумя станциями. Сделайте в нём поиск пути (любым способом) с одной станции на другую.

//class Edge{
//    var time: TimeInterval
//    var vertex: Vertex
//
//    init (time: TimeInterval, vertex: Vertex){
//        self.time = time
//        self.vertex = vertex
//    }
//}
//
//class Vertex{
//    var value: String
//    var edges: [Edge]
//
//    init(value: String, edges: [Edge]){
//        self.value = value
//        self.edges = edges
//    }
//}
//
//extension Vertex {
//    static public func ==(lhs: Vertex, rhs: Vertex) -> Bool {
//        return lhs.value == rhs.value
//    }
//}
//
//extension Edge {
//    static public func ==(lhs: Edge, rhs: Edge) -> Bool {
//        return lhs.vertex == rhs.vertex
//    }
//}
//
//func weight(from: Vertex, to: Vertex) -> TimeInterval?{
//
////    let result = from.edges.filter() {to.edges.contains($0)}
//
//    for a in from.edges{
//        for b in to.edges{
//
//            if b == a{
//                print(a.time)
//                return a.time
//            }
//        }
//    }
//    return nil
//}
//
//let serpukhovskaya = Vertex(value: "Серпуховская", edges: [polyankaSerp])
//let polyanka = Vertex(value: "Полянка", edges: [polyankaSerp, dobrOkt])
//
//let dobr = Vertex(value: "Добрынинская", edges: [])
//
//let polyankaSerp = Edge(time: 5, vertex: dobr)
//let dobrOkt = Edge(time: 7, vertex: Vertex(value: "Октябрьская", edges: []))
//
//weight(from: serpukhovskaya, to: polyanka)





//5. Реализуйте функцию сортировки массива ещё двумя способами, кроме рассказанных на уроке.


extension Array where Element: Comparable {
    
    func insertionSort() -> Array<Element> {
        //check for trivial case
        guard self.count > 1 else {
            return self
        }
        //mutated copy
        var output: Array<Element> = self
        
        for primaryindex in 0..<output.count {
            
            let key = output[primaryindex]
            var secondaryindex = primaryindex
            
            while secondaryindex > -1 {
                if key < output[secondaryindex] {
                    //move to correct position
                    output.remove(at: secondaryindex + 1)
                    output.insert(key, at: secondaryindex)
                }
                secondaryindex -= 1
            }
        }
        return output
    }
        
    func quicksort() -> [Element] {
        let array: Array<Element> = self
        guard array.count > 1 else { return array }

        let pivot = array[array.count/2]
        let less = array.filter { $0 < pivot }
        let equal = array.filter { $0 == pivot }
        let greater = array.filter { $0 > pivot }

        return less.quicksort() + equal + greater.quicksort()
    }

    
    
    
}

[165, 1, 0, 7, -3, -3, 87, 43, 65].insertionSort()
["Harry", "Ann", "Lizy", "Peter", "Ana", "Londa"].insertionSort()

[165, 1, 0, 7, -3, -3, 87, 43, 65].quicksort()
["Harry", "Ann", "Lizy", "Peter", "Ana", "Londa"].quicksort()





//Метро граф

struct Path {
    var A: Vertex
    var B: Vertex
}

class Edge {
    var time: Double
    var station: Vertex
    
    init(time: Double, station: Vertex) {
        self.time = time
        self.station = station
    }
    
}

class Vertex {
    var key: String
    var edges: [Edge]?
    
    init (key: String){ /*, edges: [Edge]*/
        self.key = key
        //self.edges = edges
    }
    
    func findPath(A: String, B: String) -> Path? {
        var result: Path?
        
        guard self.key != A else {
            guard let edges = self.edges else { return nil }
            
            for edge in edges {
                if result != nil { break }
                let station = edge.station
                result = station.key == B ? Path(A: self, B: station) : nil
            }
            
            return result
        }
        
        guard let edges = self.edges else { return nil }
        
        for edge in edges {
            if result == nil {
                result = edge.station.findPath(A: A, B: B)
            } else { return result }
        }
        
        return result
    }
    
}

let station1 = Vertex(key: "station1")
let station2 = Vertex(key: "station2")
let station3 = Vertex(key: "station3")
let station4 = Vertex(key: "station4")
let station5 = Vertex(key: "station5")

let edge1 = Edge(time: 1.0, station: station1)
let edge2 = Edge(time: 1.0, station: station2)
let edge3 = Edge(time: 1.0, station: station3)
let edge4 = Edge(time: 1.0, station: station4)
let edge5 = Edge(time: 1.0, station: station5)

station1.edges = [edge2]
station2.edges = [edge3, edge4]
station3.edges = [edge5]

let path = station1.findPath(A: "station1", B: "station2")
path?.A.key
path?.B.key

